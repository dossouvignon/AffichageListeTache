package com.example.codeurs.cmProApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmProAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
